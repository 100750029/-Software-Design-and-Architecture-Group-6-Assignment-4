package com.mycompany;


public class upcdatabase {
    public static String Banana() {
        return "Banana: $2.22";
    }
    public static String Pear() {
        return "Pear: $3.33";
    }
    public static String Apple() {
        return "Apple: $1.11";
    }

}
