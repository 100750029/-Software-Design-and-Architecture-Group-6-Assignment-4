
package com.mycompany;
// Java Swing Libraries 
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

//Declaration of class
public class gui {
    
   public static void main(String[] args) {
       //Calling of create window function
      createWindow();
   }
   //Creation of Pop out window
   private static void createWindow() {    
      JFrame frame = new JFrame("Display");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      createUI(frame);
      //setting windo size
      frame.setSize(700, 300);      
      frame.setLocationRelativeTo(null);  
      frame.setVisible(true);
   }
   //Customization of UI
   private static void createUI(final JFrame frame){  
      JPanel panel = new JPanel();
      LayoutManager layout = new FlowLayout();  
      panel.setLayout(layout);
      String product1 = upcdatabase.Banana();
      String product2 = upcdatabase.Pear();
      String product3 = upcdatabase.Apple();
      //Creation of UPC button
      JButton button = new JButton("Manual UPC Input!");
      final JLabel label = new JLabel();
      final JLabel label2 = new JLabel();
      button.addActionListener(new ActionListener() {
          //Second popout window
         @Override
         public void actionPerformed(ActionEvent e) {
            String result = (String)JOptionPane.showInputDialog(
               frame,
               "Input UPC", 
               "",            
               JOptionPane.PLAIN_MESSAGE,
               null,            
               null, 
               ""
            );
            //Checking the UPC inputted and printing out the database results
            if(result != null && result.length() > 0){
                if (result.equals("123456789")){
                    label.setText("Upc Inputted:" + result);
                    label2.setText("Product and Price is: " + product1);
                }
                else if (result.equals("456456456")){
                    label.setText("Upc Inputted:" + result);
                    label2.setText("Product and Price is: " + product2);
                }
                else if (result.equals("987654321")){
                    label.setText("Upc Inputted:" + result);
                    label2.setText("Product and Price is: " + product3);
                }
                else{
                    label.setText("UPC not found!");
                    label2.setText("");
                }
            }else {
               label.setText("None selected");
               label2.setText("");
            }
         }
      });
      //Formating buttons 
      panel.add(button);
      panel.add(label);
      panel.add(label2);
      frame.getContentPane().add(panel, BorderLayout.CENTER);

   }  
} 